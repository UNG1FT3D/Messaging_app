package com.example.tar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Objects;

public class Homepage extends AppCompatActivity {
    FirebaseAuth auth;
    RecyclerView mainUserRecyclerView;
    UserAdapter adapter;
    FirebaseDatabase database;
    FirebaseFirestore db;
    FloatingActionButton inviteBtn;
    String userID;
    ImageView logout;
    ArrayList<Users> usersArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        auth=FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();
        database=FirebaseDatabase.getInstance();

        userID= Objects.requireNonNull(auth.getCurrentUser().getUid());
        usersArrayList =new ArrayList<>();

        logout=findViewById(R.id.logout);
        inviteBtn=findViewById(R.id.inviteBtn);
        mainUserRecyclerView=findViewById(R.id.mainUSerRecyclerview);

        LinearLayoutManager manager=new LinearLayoutManager(this);
        mainUserRecyclerView.setLayoutManager(manager);
        mainUserRecyclerView.setHasFixedSize(true);
        adapter=new UserAdapter(this,usersArrayList);
        mainUserRecyclerView.setAdapter(adapter);

        inviteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Homepage.this,InvitePage.class);
                startActivity(intent);
            }
        });





        if(auth.getCurrentUser()==null){
            startActivity(new Intent(Homepage.this,Login.class));
        }

        /*db.collection("user").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {

                    if(error!= null){
                        Log.d("Error",error.getMessage());
                    }
                    for(DocumentChange documentChange:value.getDocumentChanges()){
                        if(documentChange.getType()==DocumentChange.Type.ADDED){
                            usersArrayList.add(documentChange.getDocument().toObject(Users.class));
                        }
                        adapter.notifyDataSetChanged();
                    }
            }
        });*/
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(Homepage.this, Login.class));
                finish();
            }
        });



        DatabaseReference reference=database.getReference().child("user");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Users users=dataSnapshot.getValue(Users.class);
                    usersArrayList.add(users);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

}