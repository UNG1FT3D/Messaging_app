package com.example.tar;

public class Users {

    String email;
    String Name;
    String password;
    String phone;
    String status;
    String uid;

    public Users() {
    }

    public Users(String email, String name, String password, String phone, String status, String uid) {
        this.email = email;
        this.Name = name;
        this.password = password;
        this.phone = phone;
        this.status = status;
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
