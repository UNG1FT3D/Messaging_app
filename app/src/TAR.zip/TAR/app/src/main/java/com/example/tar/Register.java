package com.example.tar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class Register extends AppCompatActivity {

    CircleImageView profile_image;
    TextInputLayout reg_name, reg_password, reg_email, reg_phone;
    Button registerBtn,txt_login;
    FirebaseAuth auth;
    FirebaseDatabase database;
    FirebaseFirestore db;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        auth = FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
        db= FirebaseFirestore.getInstance();
        registerBtn = findViewById(R.id.registerBtn);
        txt_login = findViewById(R.id.txt_login);
        profile_image = findViewById(R.id.profile_image);
        txt_login.setOnClickListener(view -> startActivity(new Intent(Register.this, Login.class)));

        reg_name = findViewById(R.id.reg_name);
        reg_password = findViewById(R.id.reg_password);
        reg_email = findViewById(R.id.reg_email);
        reg_phone = findViewById(R.id.reg_phone);
        if(auth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(),Homepage.class));
            finish();
        }

        registerBtn.setOnClickListener(view -> {
            String email = reg_email.getEditText().getText().toString();
            String password = reg_password.getEditText().getText().toString();
            String phone = reg_phone.getEditText().getText().toString();
            String name = reg_name.getEditText().getText().toString();


            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(password) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(email)) {
                Toast.makeText(Register.this, "Enter value", Toast.LENGTH_SHORT).show();
            }else {
                auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        userID = auth.getCurrentUser().getUid();
                        DocumentReference documentReference = db.collection("user").document(userID);
                        Map<String, Object> user = new HashMap<>();

                        user.put("email", email);
                        user.put("Name", name);
                        user.put("password", password);
                        user.put("phone", phone);
                        user.put("uid", auth.getUid());

                        documentReference.set(user).addOnSuccessListener(unused -> Log.d("User created", userID));
                        DatabaseReference reference = database.getReference().child("user").child(Objects.requireNonNull(auth.getUid()));
                        String status = "hey am new here";
                        Users users = new Users(email, name, password, phone, status, auth.getUid());
                        reference.setValue(users).addOnCompleteListener(task1 -> {
                            if (task1.isSuccessful()) {
                                startActivity(new Intent(Register.this, Login.class));
                            }
                        });

                    } else {
                        Toast.makeText(Register.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });


    }


}