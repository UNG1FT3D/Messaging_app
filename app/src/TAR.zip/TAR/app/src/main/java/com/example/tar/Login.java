package com.example.tar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    //EditText etLoginEmail;
    //EditText etLoginPassword;
    TextInputLayout etLoginEmail;
    TextInputLayout etLoginPassword;
    //TextView  RegisterNow;
    FirebaseAuth auth;
    TextView  forgotPass;
    Button btnLogin,RegisterNow;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etLoginEmail=findViewById(R.id.Username);
        etLoginPassword=findViewById(R.id.Password);
        RegisterNow=findViewById(R.id.register);
        //forgotPass=findViewById(R.id.);
        auth = FirebaseAuth.getInstance();
        btnLogin=findViewById(R.id.login);
        mAuth=FirebaseAuth.getInstance();

        if(auth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(),Homepage.class));
            finish();
        }

        btnLogin.setOnClickListener(view ->{
            loginUser();
        });
        RegisterNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Login.this,Register.class);
                startActivity(intent);
            }
        });




    }
    private void loginUser(){
        String email = etLoginEmail.getEditText().getText().toString();
        String password = etLoginPassword.getEditText().getText().toString();

        if (TextUtils.isEmpty(email)){
            etLoginEmail.setError("Email Cannot be empty");
            etLoginEmail.requestFocus();
        }else if (TextUtils.isEmpty(password)){
            etLoginPassword.setError("Password cannot be empty");
            etLoginPassword.requestFocus();
        }else{
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){


                        Toast.makeText(Login.this,"User Logged in successfully",Toast.LENGTH_SHORT).show();

                        Intent intent=new Intent(Login.this,Homepage.class);
                        intent.putExtra("data",email);

                        startActivity(new Intent(Login.this,Homepage.class));
                        startActivity(intent);
                    }else{
                        Toast.makeText(Login.this,"Login error",Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }


}
