package com.example.tar;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;


public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder> {
    Context context;
    ArrayList<Users> usersArrayList;
    public UserAdapter(Homepage homepage, ArrayList<Users> usersArrayList) {
        this.context =homepage;
        this.usersArrayList=usersArrayList;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.item_user_row,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {


        Users users=usersArrayList.get(position);
        String senderId=FirebaseAuth.getInstance().getUid();
        String senderRoom=senderId+users.getUid();

        FirebaseDatabase.getInstance().getReference()
                .child("chats")
                .child(senderRoom)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //Collections.sort(usersArrayList,Collections.reverseOrder());
                        if(snapshot.exists()){
                            String lastMsg=snapshot.child("lastMsg").getValue(String.class);
                            //long time=snapshot.child("lastMsgTime").getValue(Long.class);
                            SimpleDateFormat dateFormat= new SimpleDateFormat("hh:mm a");
                            //holder.time.setText(dateFormat.format(new Date(time)));
                            holder.phone.setText(lastMsg);

                        }else {
                            holder.phone.setText("Tap on Chat");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


        if(FirebaseAuth.getInstance().getCurrentUser().getUid().equals(users.getUid())){
            holder.itemView.setVisibility(View.GONE);
            holder.itemView.setLayoutParams(new RecyclerView.LayoutParams(0, 0));
        }
        //holder.phone.setText(users.phone);
        holder.name.setText(users.Name);
        //holder.Uid.setText(users.uid);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context,ChatActivity.class);
                    intent.putExtra("Name",users.getName());
                    intent.putExtra("uid",users.getUid());
                    context.startActivity(intent);
                }
            });



        /*holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(),Chatpannel.class);
                i.putExtra("Name",users.getName());
                i.putExtra("phone",users.getPhone());
                //i.putExtra("uid",users.getUid());
                view.getContext().startActivity(i);
                //homepage.startActivity(intent);
                Toast.makeText(homepage, "Clicked", Toast.LENGTH_SHORT).show();

            }
        });*/

    }

    @Override
    public int getItemCount() {

        return usersArrayList.size();
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView name,phone,time;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            //itemView.setOnClickListener(view -> {
              //  Intent intent=new Intent(view.getContext(),ChatActivity.class);
               // intent.putExtra("Name",name.getText());
               // intent.putExtra("Phone",phone.getText());
                //intent.putExtra("uid",Uid.getText());
              //  view.getContext().startActivity(intent);
            //});

            name=itemView.findViewById(R.id.Profile_Name);
            phone=itemView.findViewById(R.id.lastMsg);
            time=itemView.findViewById(R.id.lastMsgTime);



        }
    }
}
